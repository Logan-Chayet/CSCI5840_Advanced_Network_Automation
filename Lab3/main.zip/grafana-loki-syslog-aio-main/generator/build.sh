docker build -t docker01.tylephony.com:5000/lux4rd0/syslog-generator:latest -f Dockerfile --no-cache .

docker push docker01.tylephony.com:5000/lux4rd0/syslog-generator:latest
